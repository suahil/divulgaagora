import React, { Component } from 'react'

export default class Home extends Component {
    state = {
        anuncios: [],
        anuncio:"",
        idAnuncio:"",
        visualizando: false
    }

    preencherLista = () => {
        const url = window.servidor + '/anuncio/aprovados'
        fetch(url)
            .then(response => response.json())
            .then(data => this.setState({anuncios: data}))
    }
    
    visualizaAnuncio = (id) => {
        const url = window.servidor + '/anuncio/visualizar/' + id
        fetch(url)
            .then(response => response.json())
            .then(data => this.setState({anuncio: data}))
            //.then(this.setState({visualizando: true}))
            .catch(erro => console.log(erro))
    //<button type="submit" className="btn btn-link" onClick={this.visualizaAnuncio(anuncio.id)}><tr>{anuncio.descricao}</tr></button>
    }

    componentDidMount(){
        this.preencherLista()
    }

    /*visualizarAnuncio = (id) => {
        this.setState({idAnuncio: id, visualizando: true})
        <tr><button type="submit" className="btn btn-link" onClick={this.visualizarAnuncio(anuncio.id)} >{anuncio.descricao}</button></tr>
    }*/
    
    renderHome() {
        return (
                    <div className="row text-center mt-4 p-5">
                        <table id="tabela" className="table">
                            <tbody>
                                {this.state.anuncios && this.state.anuncios.map(anuncio => {
                                    return <th key={anuncio.id} >
                                                <th scope="col">{anuncio.categoria}</th>
                                                <tr>{anuncio.nome}</tr>
                                                <tr><img src={anuncio.fotoFornecedor} alt="Foto Fornecedor" width="30%" className="img-thumbnail img-fluid rounded mx-auto d-block" ></img></tr>
                                                <tr>{anuncio.descricao}</tr>
                                            </th>
                                })}
                            </tbody>
                        </table>
                    </div>
                
            )
    }
    renderBusca() {
        return (
                    <div className="row text-center mt-4 p-5">
                        <table id="tabela" className="table">
                            <tbody>
                                {this.props.anunciosbusca && this.props.anunciosbusca.map(anuncio => {
                                    return <th key={anuncio.id} >
                                            <th scope="col">{anuncio.categoria}</th>
                                            <tr>{anuncio.nome}</tr>
                                            <tr><img src={anuncio.fotoFornecedor} alt="Foto Fornecedor" width="30%" className="img-thumbnail img-fluid rounded mx-auto d-block" ></img></tr>
                                            <tr>{anuncio.descricao}</tr>
                                        </th>
                                })}
                            </tbody>
                        </table>
                    </div>
                
            )
    }

    renderVisualizaAnuncio(){
        return (
            <div className="text-center mt-8 p-5">
                <br/>
                <br/>
                {this.state.anuncio.descricao}
            </div>
        )
    }
    render() {
        let pagina = ''
        if((!this.props.anunciosbusca)&&(!this.state.visualizando)){
            pagina=this.renderHome()
        }else 
            if(this.state.visualizando){
                pagina=this.renderVisualizaAnuncio()
            }else
                pagina=this.renderBusca()
        return pagina
    }
}
