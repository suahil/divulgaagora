import React, { Component } from 'react'
import Login from '../login/Login'

export default class Anuncio extends Component {
    fileObj = [];
    fileArray = [];
    
    state = {
        anuncio: "",
        id: "",
        nome:"",
        descricao:"",
        valor:"",
        categorias:[],
        categoria:"",
        email:"",
        buscaEmail: "",
        senha:"",
        tipos: [],
        tipoProduto:"",
        fotos: [],
        aprovacao:"",
        anuncios: [],
        incluindo: false,
        alterando: false,
        buscando: false,
        usuario: "",
        logado: false,
        file: []
    }

    constructor(props) {
        super(props)
        
        this.state = {
            usuario: this.props.usuario, 
            logado:this.props.logado,
            
        }
        this.uploadMultipleFiles = this.uploadMultipleFiles.bind(this)
        this.uploadFiles = this.uploadFiles.bind(this)
    }
    txtNome_change = (event) => {
        this.setState({nome: event.target.value})
    }
    txtDescricao_change = (event) => {
        this.setState({descricao: event.target.value})
    }
    txtValor_change = (event) => {
        this.setState({valor: event.target.value})
    }
    txtEmail_change = (event) => {
        this.setState({email: event.target.value})
    }
    txtSenha_change = (event) => {
        this.setState({senha: event.target.value})
    }
    txtAprovacao_change = (event) => {
        this.setState({aprovacao: event.target.value})
    }
    cbotipo_change = (event) => {
        this.setState({tipoAnuncio: event.target.value})
    }
    cboCategoria_change = (event) => {
        this.setState({categoria: event.target.value})
    } 
    buscaEmail_change = (event) => {
        this.setState({buscaEmail: event.target.value})
    } 

    carregar_tipos = () => {
        const url = window.servidor + '/anuncio/tipos'
        
        fetch(url)
            .then(response => response.json())
            .then(datat =>{
                this.setState({tipos: datat})
                
            })
            
    }
    
    carregar_categorias = () => {
        const url = window.servidor + '/categoria/'
        
        fetch(url)
            .then(response => response.json())
            .then(datac =>{
                this.setState({categorias: datac})
                
            })
            
    }

    preencherLista = () => {
        const url = window.servidor + '/anuncio/fornecedor/' + this.props.usuario.email
        fetch(url)
            .then(response => response.json())
            .then(data => this.setState({anuncios: data}));
    }
    
    preencherListaReprovados = () => {
        const url = window.servidor + '/anuncio/reprovados'
        fetch(url)
            .then(response => response.json())
            .then(data => this.setState({anuncios: data}));
    }

    buscarEmail = (buscaEmail) => {
        const requestOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
            
        };

        const url = window.servidor + '/anuncio/email/' + buscaEmail

        fetch(url, requestOptions)
        .then(response => response.json())
        .then(dataa => this.setState({anuncio: dataa}))
        .then(this.setState({buscando: true}))
        .catch(erro => console.log(erro));
    }
    componentDidMount(){
        this.carregar_tipos()
        this.carregar_categorias()
        
    }
    
    aprovarAnuncio = (id,usuario) => {
            const dados = {
                "id": this.state.anuncio.id,
                "usuario": this.props.usuario
            }
    
            const requestOptions = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dados)
            };
    
            const url = window.servidor + '/anuncio/aprovar/' + id + '/' + usuario
    
            fetch(url, requestOptions)
                .then(fim =>{
                    this.preencherListaReprovados()
                })
                
        }
    
    voltar = () => {
        this.setState({incluindo: false, alterando: false})
    }

    iniciarNovo = () => {
        this.setState({incluindo: true, tipoProduto: ''})
    }

    incluirNovo = () => {
        const dados = {
            "nome": this.state.nome,
            "descricao": this.state.descricao,
            "valor": this.state.valor,
            "tipoProduto": this.state.tipoProduto,
            "fornecedor": this.props.usuario,
            "categoria": this.state.categoria,
            "fotos": this.state.fotos
        }

        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        };

        const url = window.servidor + '/anuncio/incluir'

        fetch(url, requestOptions)
            .then(fim =>{
                this.setState({incluindo: false})
                this.preencherLista()
            })
            .catch(erro => console.log(erro))

    }

    uploadMultipleFiles(e) {
        this.fileObj.push(e.target.files)
        for (let i = 0; i < this.fileObj[0].length; i++) {
            this.fileArray.push(URL.createObjectURL(this.fileObj[0][i]))
        }
        this.setState({ file: this.fileArray })
    }

    uploadFiles() {
        
        
    }

    renderExibirLista = () => {
        
        return (
            <div className="mt-5 pt-4">
                <div className="col-5 container ">
                    <form className="form-inline">
                        <input id="txt_consulta" className="form-control" onChange={this.buscaEmail_change} type="search" placeholder="Pesquisar" aria-label="Pesquisar"></input>
                        <div className="mt-1 row justify-content-center align-items-center">
                            <button className="w-25 btn btn-dark" onClick={() => this.buscarEmail(this.state.buscaEmail)} type="button"><i class="bi bi-search"></i>  Pesquisar</button>
                        </div>
                    </form>
                </div>
                <button type="button" className="btn btn-dark" onClick={() => this.iniciarNovo()}><i className="bi bi-plus"></i> Novo</button>
                <div className="row text-center">
                    <table id="tabela" className="table">
                        <tbody>
                            {this.state.anuncios && this.state.anuncios.map(anuncio => {
                                return <th key={anuncio.id}>
                                    <th scope="col">{anuncio.categoria}</th>
                                    <tr>{anuncio.nome}</tr>
                                    <tr><img src={anuncio.fotoFornecedor} alt="Foto Fornecedor" width="30%" className="img-thumbnail img-fluid rounded mx-auto d-block" ></img></tr>
                                    <tr>{anuncio.descricao}</tr>
                                    <tr>Aprovação: {anuncio.aprovacao}</tr>
                                    <tr>
                                        <button onClick={() => this.iniciarAlterar(anuncio)} type="button" className="btn btn-outline-dark" data-toggle="tooltip" data-placement="top" title="Editar um usuário"> <i className="bi bi-pencil"></i></button>
                                        <button onClick={() => this.excluir(anuncio)} type="button" className="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Excluir um usuário"> <i className="bi bi-trash"></i></button>
                                    </tr>
                                </th>
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
    
    renderExibirListaAdm = () => {
        
        return (
            <div className="mt-5 pt-4">
                <div className="row text-center">
                    <table id="tabela" className="table">
                        <tbody>
                            {this.state.anuncios && this.state.anuncios.map(anuncio => {
                                return <th key={anuncio.id}>
                                    <th scope="col">{anuncio.categoria}</th>
                                    <tr>{anuncio.nome}</tr>
                                    <tr><img src={anuncio.fotoFornecedor} alt="Foto Fornecedor" width="40%" className="img-thumbnail img-fluid rounded mx-auto d-block" ></img></tr>
                                    <tr>{anuncio.descricao}</tr>
                                    <tr>{anuncio.aprovacao}</tr>
                                    <tr>
                                        <button onClick={() => this.aprovarAnuncio(anuncio, this.state.usuario)} type="button" className="btn btn-success" data-toggle="tooltip" data-placement="top" title="Aprovar um anúncio"> <i className="bi bi-check2"></i></button>
                                        <button onClick={() => this.excluir(anuncio)} type="button" className="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Excluir um anúncio"> <i className="bi bi-trash"></i></button>
                                    </tr>
                                </th>
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }

    renderIncluirNovo = () => {
        return (
            <div >
                <div className="col-4 mt-1 pt-1">
                        <label className="form-label">Tipo:</label>
                        <select value={this.state.tipoProduto} className="form-select"  onChange={this.cbotipo_change}>
                            {this.state.tipos.map((tipo) => (
                                <option key={tipo} value={tipo}>{tipo}</option>

                            ))}
                        </select>
                </div>
                <div className="row mt-1">
                    <div className="col-2 mt-1">
                        <label className="form-label"> Nome: </label>
                    </div>
                    <div className="row mt-1">
                        <div className="col-4">
                            <input value={this.state.nome} onChange={this.txtNome_change} type="text" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    
                    <div className="col-2 mt-1">
                        <label className="form-label"> Descrição: </label>
                    </div>
                    <div className="row mt-1">
                        <div className="col-4">
                            <input value={this.state.descricao} onChange={this.txtDescricao_change} type="text" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    
                    <div className="col-2 mt-1">
                        <label className="form-label"> Valor: </label>
                    </div>
                    <div className="row mt-1">
                        <div className="col-4">
                            <input value={this.state.valor} onChange={this.txtValor_change} type="text" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    
                    <div className="col-4 mt-1 ">
                        <label className="form-label">Categoria:</label>
                        <select value={this.state.categoria} className="form-select"  onChange={this.cboCategoria_change}>
                            {this.state.categorias.map((categoria) => (
                                <option key={categoria.id} value={categoria.id}>{categoria.nome}</option>

                            ))}
                        </select>
                    </div>
                    
                    
                    <div className="form-label multi-preview">
                        {(this.fileArray || []).map(url => (
                            <img src={url} alt="..." width="100px" />
                        ))}
                    </div>
                    <div className="form-label col-4">
                        <input type="file" className="form-control" onChange={this.uploadMultipleFiles} multiple />
                    </div>
                    <div className="col-3">
                        <button type="button" className="btn btn-outline-primary" onClick={this.uploadFiles}>Upload</button>
                    </div>
                    <div className="row mt-1">
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.incluirNovo()}>Gravar</button>
                        </div>
                        <div className="col-1 mb-5">
                            <button className="btn btn-primary" onClick = {() => this.voltar()}>Voltar</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    
    iniciarExibir = (anuncio) => {
        this.setState({exibindo: true})
    }

    renderExibirAnuncio = () => {
        return (
            <div >
                <div className="col-4 mt-1 pt-1">
                        <label className="form-label">Tipo:</label>
                        <select value={this.state.tipoProduto} className="form-select"  onChange={this.cbotipo_change}>
                            {this.state.tipos.map((tipo) => (
                                <option key={tipo} value={tipo}>{tipo}</option>

                            ))}
                        </select>
                </div>
                <div className="row mt-1">
                    <div className="col-2 mt-1">
                        <label className="form-label"> Nome: </label>
                    </div>
                    <div className="row mt-1">
                        <div className="col-4">
                            <input value={this.state.nome} onChange={this.txtNome_change} type="text" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    
                    <div className="col-2 mt-1">
                        <label className="form-label"> Descrição: </label>
                    </div>
                    <div className="row mt-1">
                        <div className="col-4">
                            <input value={this.state.descricao} onChange={this.txtDescricao_change} type="text" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    
                    <div className="col-2 mt-1">
                        <label className="form-label"> Valor: </label>
                    </div>
                    <div className="row mt-1">
                        <div className="col-4">
                            <input value={this.state.valor} onChange={this.txtValor_change} type="text" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    
                    <div className="col-4 mt-1 ">
                        <label className="form-label">Categoria:</label>
                        <select value={this.state.categoria} className="form-select"  onChange={this.cboCategoria_change}>
                            {this.state.categorias.map((categoria) => (
                                <option key={categoria.id} value={categoria.id}>{categoria.nome}</option>

                            ))}
                        </select>
                    </div>
                    
                    
                    <div className="form-label multi-preview">
                        {(this.fileArray || []).map(url => (
                            <img src={url} alt="..." width="100px" />
                        ))}
                    </div>
                    <div className="form-label col-4">
                        <input type="file" className="form-control" onChange={this.uploadMultipleFiles} multiple />
                    </div>
                    <div className="col-3">
                        <button type="button" className="btn btn-outline-primary" onClick={this.uploadFiles}>Upload</button>
                    </div>
                    <div className="row mt-1">
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.incluirNovo()}>Gravar</button>
                        </div>
                        <div className="col-1 mb-5">
                            <button className="btn btn-primary" onClick = {() => this.voltar()}>Voltar</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    render() {
        let pagina = ''
        if(!this.state.logado)
            pagina = <Login/>    
        else
            if(this.state.incluindo)
                pagina = this.renderIncluirNovo()
            else
                if(this.props.usuario.tipoUsuario==='ADMINISTRADOR'){
                    this.preencherListaReprovados()
                    pagina = this.renderExibirListaAdm()
                } else {
                    this.preencherLista()
                    pagina = this.renderExibirLista()
            }
            
        return pagina
    }
}
                                    
