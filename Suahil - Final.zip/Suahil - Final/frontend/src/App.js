import React, { Component } from 'react'
import { Route, Switch } from 'react-router'
import { BrowserRouter } from 'react-router-dom'
import Anuncio from './anuncio/Anuncio'
import Fornecedor from './fornecedor/Fornecedor'
import Home from './home/Home'
import Login from './login/Login'
import Menu from './menu/Menu'
import Rodape from './rodape/Rodape'
import Usuario from './usuario/Usuario'


export default class App extends Component {
  state = {
    usuario:[],
    anuncios:false,
    logado: false,
    fornecedor:""

  }

  carregarFornecedor = () => {
    const url = window.servidor + '/fornecedor/buscarFornecedor/' + this.state.usuario.id
    fetch(url)
      .then(response => response.json())
      .then(data => {
        this.setState({ fornecedor: data })
      })
    
  }

  buscarAnuncio = (busca) => {
    const url = window.servidor + '/anuncio/aprovados/' + busca
    fetch(url)
      .then(response => response.json())
      .then(data => {
        this.setState({ anuncios: data })
      })
    
  }

  logar = (email,senha) => {
    const requestOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
        
    };

    const url = window.servidor + '/usuario/logar/' + email + '/' + senha

    fetch(url, requestOptions)
    .then(response => response.json())
    .then(data => this.setState({usuario: data,logado:true}))
    .catch(erro => console.log(erro));
  }

  sair = () => {
    this.setState({usuario: [], logado:false})
  }
  
  
    
  render() {
    return (
      <BrowserRouter>
        <div className="container-fluid">
          <Menu deslogar={this.sair} usuario={this.state.usuario} logado={this.state.logado} carregarFornecedor={this.carregarFornecedor} buscarAnuncio={this.buscarAnuncio}/>
          <Switch>
            <Route exact path="/">
              <Home anunciosbusca={this.state.anuncios}/>
            </Route>
            <Route path="/usuario">
              <Usuario logado={this.state.logado} />
            </Route>
            <Route path="/login">
              <Login autenticar={this.logar} usuario={this.state.usuario} logado={this.state.logado} fornecedor={this.state.fornecedor} />
            </Route>
            <Route path="/anuncio">
              <Anuncio usuario={this.state.usuario} logado={this.state.logado} />
            </Route>
            <Route path="/fornecedor">
              <Fornecedor fornecedor={this.state.fornecedor}/>
            </Route>
          </Switch>
          <Rodape />
        </div>
      </BrowserRouter>
    )
  }
}
