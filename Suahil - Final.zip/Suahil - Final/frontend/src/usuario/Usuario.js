import React, { Component } from 'react'
import Fornecedor from '../fornecedor/Fornecedor'
import Login from '../login/Login'

export default class Usuario extends Component {
    
    state = {
        usuario: "",
        id: "",
        email:"",
        buscaEmail: "",
        senha:"",
        tipos: [],
        tipoUsuario:"",
        usuarios: [],
        incluindo: false,
        alterando: false,
        buscando: false,
        novoUsuario: false,
        voltando: false
    }

    txtEmail_change = (event) => {
        this.setState({email: event.target.value})
    }
    txtSenha_change = (event) => {
        this.setState({senha: event.target.value})
    }
    cbotipo_change = (event) => {
        this.setState({tipoUsuario: event.target.value})
    } 
    buscaEmail_change = (event) => {
        this.setState({buscaEmail: event.target.value})
    } 

    carregar_tipos = () => {
        const url = window.servidor + '/usuario/tipos'
        
        fetch(url)
            .then(response => response.json())
            .then(data =>{
                this.setState({tipos: data})
                
            })
            
    }

    preencherLista = () => {
        const url = window.servidor + '/usuario/listaraz'
        fetch(url)
            .then(response => response.json())
            .then(data => this.setState({usuarios: data}));
    }

    buscarEmail = (buscaEmail) => {
        const requestOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
            
        };

        const url = window.servidor + '/usuario/email/' + buscaEmail

        fetch(url, requestOptions)
        .then(response => response.json())
        .then(data => this.setState({usuario: data}))
        .then(this.setState({buscando: true}))
        .catch(erro => console.log(erro));

    }

    componentDidMount(){
        this.preencherLista()
        this.carregar_tipos()
        
    }

    iniciarNovo = () => {
        this.setState({incluindo: true, email: '', senha: '', tipoUsuario: ''})
    }

    iniciarAlterar = (usuario) => {
        this.setState({alterando: true, id: usuario.id, senha: usuario.senha, email: usuario.email, tipoUsuario: usuario.tipoUsuario})
    }

    incluirNovo = () => {
        const dados = {
            "email": this.state.email,
            "senha": this.state.senha,
            "tipoUsuario": this.state.tipoUsuario
        }

        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        };

        const url = window.servidor + '/usuario/incluir'

        fetch(url, requestOptions)
            .then(fim =>{
                this.setState({incluindo: false})
                this.preencherLista()
            })
            .catch(erro => console.log(erro))

    }
    
    incluirNovoDeslogado = () => {
        const dados = {
            "email": this.state.email,
            "senha": this.state.senha,
            "tipoUsuario": 'FORNECEDOR'
        }

        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        };

        const url = window.servidor + '/usuario/incluir'

        fetch(url, requestOptions)
            .then(response => response.json())
            .then(data => {
                    this.setState({ novoUsuario: data })    

            })
            .catch(erro => console.log(erro))

    }
    
    alterar = () => {
        const dados = {
            "id": this.state.id,
            "email": this.state.email,
            "senha": this.state.senha,
            "tipoUsuario": this.state.tipoUsuario
        }

        const requestOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        };

        const url = window.servidor + '/usuario/alterar'

        fetch(url, requestOptions)
            .then(fim =>{
                this.setState({alterando: false})
                this.preencherLista()
            })
            
    }
    
    excluir = (usuario) => {
        const requestOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
            
        };

        const url = window.servidor + '/usuario/excluir/' + usuario.id

        fetch(url, requestOptions)
            .then(fim =>{
                this.preencherLista()
            })    
            .catch(erro => console.log(erro))

    }
    voltar = () => {
        this.setState({incluindo: false, alterando: false})
    }
    voltar1 = () => {
        this.setState({voltando: true})
    }
    renderIncluirNovo = () => {
        return (
            <div >
                <div className="row mt-2 pt-3">
                    <div className="col-2 mt-4 pt-3">
                        <label className="form-label"> E-mail: </label>
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input value={this.state.email} onChange={this.txtEmail_change} type="email" id="staticEmail" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    <div className="col-2 mt-4 pt-1">
                        Senha:
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input type="password" id="inputPassword" value={this.state.senha} onChange={this.txtSenha_change}  className="form-control name-pull-image"></input>
                        </div>
                    </div>
                    
                    <div className="col-4 mt-4 pt-1">
                        <label className="form-label">Tipo:</label>
                        <select value={this.state.tipoUsuario} className="form-select"  onChange={this.cbotipo_change}>
                            {this.state.tipos.map((tipo) => (
                                <option key={tipo} value={tipo}>{tipo}</option>

                            ))}
                        </select>
                    </div>
                    
                    <div className="row mt-2">
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.incluirNovo()}>Gravar</button>
                        </div>
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.voltar()}>Voltar</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
    renderIncluirNovoDeslogado = () => {
        return (
            <div className="row mt-4 pt-5" >
                <h4>CRIE SEU USUÁRIO</h4>
                <div className="row">
                    <div className="col-2 mt-4 pt-3">
                        <label className="form-label"> E-mail: </label>
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input value={this.state.email} onChange={this.txtEmail_change} type="email" id="staticEmail" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    <div className="col-2 mt-4 pt-1">
                        Senha:
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input type="password" id="inputPassword" value={this.state.senha} onChange={this.txtSenha_change}  className="form-control name-pull-image"></input>
                        </div>
                    </div>
                    <div className="row mt-2">
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.incluirNovoDeslogado()}>Gravar</button>
                        </div>
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.voltar1()}>Voltar</button>
                        </div>
                        
                    </div>
                </div>
            </div>
        )
    }
    
    renderAlterar = () => {
        return (
            <div >
                <div className="row mt-2 pt-3">
                    <div className="col-2 mt-4 pt-3">
                        ID:
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input value={this.state.id} readOnly className="form-control name-pull-image" type="text"></input>
                        </div>
                    </div>
                    <div className="col-2 mt-4 pt-3">
                        E-mail:
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input value={this.state.email} onChange={this.txtEmail_change} type="email" id="staticEmail" className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    <div className="col-2 mt-4 pt-1">
                        Senha:
                    </div>
                    <div className="row mt-2">
                        <div className="col-4">
                            <input type="password" id="inputPassword" value={this.state.senha} onChange={this.txtSenha_change} className="form-control name-pull-image" ></input>
                        </div>
                    </div>
                    <div className="col-4 mt-4 pt-1">
                        <label className="form-label">Tipo:</label>
                        <select value={this.state.tipoUsuario} className="form-select"  onChange={this.cbotipo_change}>
                            {this.state.tipos.map((tipo) => (
                                <option key={tipo} value={tipo}>{tipo}</option>

                            ))}
                        </select>
                    </div>
                    <div className="row mt-2">
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.alterar()}>Gravar</button>
                        </div>
                        <div className="col-1">
                            <button className="btn btn-primary" onClick = {() => this.voltar()}>Voltar</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    renderExibirLista = () => {
        return (
            <div className="mt-5 pt-4">
                <div className="col-5 container ">
                    <form className="form-inline">
                        <input id="txt_consulta" className="form-control" onChange={this.buscaEmail_change} type="search" placeholder="Pesquisar" aria-label="Pesquisar"></input>
                        <div className="mt-1 row justify-content-center align-items-center">
                            <button className="w-25 btn btn-dark" onClick={() => this.buscarEmail(this.state.buscaEmail)} type="button"><i class="bi bi-search"></i>  Pesquisar</button>
                        </div>
                    </form>
                </div>
                <button type="button" className="btn btn-dark" onClick={() => this.iniciarNovo()}><i className="bi bi-plus"></i> Novo</button>
                <table id="tabela" className="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Email</th>
                            <th scope="col">Tipo Usuario</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.usuarios && this.state.usuarios.map(usuario => {
                            return <tr key={usuario.id}>
                                <th scope="row">{usuario.id}</th>
                                <td>{usuario.email}</td>
                                <td>{usuario.tipoUsuario}</td>
                                <td> <button onClick={() => this.iniciarAlterar(usuario)} type="button" className="btn btn-outline-dark" data-toggle="tooltip" data-placement="top" title="Editar um usuário"> <i className="bi bi-pencil"></i></button></td>
                                <td> <button onClick={() => this.excluir(usuario)} type="button" className="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Excluir um usuário"> <i className="bi bi-trash"></i></button></td>
                            </tr>
                        })}
                    </tbody>
                </table>
            </div>
        );
    }
    renderExibirListaBusca = () => {
        return (
            <div className="mt-5 pt-4">
                <div className="col-5 container ">
                    <form className="form-inline">
                        <input id="txt_consulta" className="form-control" onChange={this.buscaEmail_change} type="search" placeholder="Pesquisar" aria-label="Pesquisar"></input>
                        <div className="mt-1 row justify-content-center align-items-center">
                            <button className="w-25 btn btn-dark" onClick={() => this.buscarEmail(this.state.buscaEmail)} type="submit"><i class="bi bi-search"></i>  Pesquisar</button>
                        </div>
                    </form>
                </div>
                <button type="button" className="btn btn-dark" onClick={() => this.iniciarNovo()}><i className="bi bi-plus"></i> Novo</button>
                <table id="tabela" className="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Email</th>
                            <th scope="col">Tipo Usuario</th>
                            <th scope="col"></th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr key={this.state.usuario.id}>
                            <th scope="row">{this.state.usuario.id}</th>
                            <td>{this.state.usuario.email}</td>
                            <td>{this.state.usuario.tipoUsuario}</td>
                            <td> <button onClick={() => this.iniciarAlterar(this.state.usuario)} type="button" className="btn btn-outline-dark" data-toggle="tooltip" data-placement="top" title="Editar um usuário"> <i className="bi bi-pencil"></i></button></td>
                            <td> <button onClick={() => this.excluir(this.state.usuario)} type="button" className="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Excluir um usuário"> <i className="bi bi-trash"></i></button></td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        );
    }
    
    render() {
        let pagina = ''
        if(this.state.novoUsuario)
            pagina = <Fornecedor novoUsuario={this.state.novoUsuario}/>
        else
            if((!this.props.logado)&&(!this.state.voltando))
                pagina = this.renderIncluirNovoDeslogado()
            else 
                if(this.state.voltando)
                    pagina = <Login/>
                else 
                    if(this.state.incluindo)
                        pagina = this.renderIncluirNovo()
                    else 
                        if(this.state.alterando)
                            pagina = this.renderAlterar()
                        else  
                            if(this.state.buscando) 
                                pagina = this.renderExibirListaBusca()
                            else 
                                pagina = this.renderExibirLista()
        return pagina
    }    
}

