import React, { Component } from 'react'
import Login from '../login/Login'
import Anuncio from '../anuncio/Anuncio'

export default class Fornecedor extends Component {
    
    state ={
        id: "",
        cep: "",
        endereco: "",
        facebook: "",
        foto: "",
        instagram: "",
        nome: "",
        telefone: "",
        tipo:"",
        url:"",
        whatsapp:"",
        bairro:"",
        usuario:"",
        fornecedor:"",
        fornecedores: [],
        bairros:[],
        alterando: true,
        gravado: false,
        voltar: false
    }

    txtNome_change = (event) =>{
        this.setState({nome: event.target.value})
    }
    txtNome_change = (event) =>{
        this.setState({nome: event.target.value})
    }
    txtEndereco_change = (event) =>{
        this.setState({endereco: event.target.value})
    }
    txtCep_change =(event)=>{
        this.setState({cep: event.target.value})
    }
    txtFacebook_change = (event) =>{
        this.setState({facebook: event.target.value})
    }
    foto_change = (event) =>{
        var reader = new FileReader()
        reader.readAsDataURL(event.target.files[0])
        reader.onload = () => {
            this.setState({foto: reader.result})
        }
    }
    txtInstagram_change = (event) =>{
        this.setState({instagram: event.target.value})
    }
    txtWhatsapp_change =(event)=>{
        this.setState({whatsapp: event.target.value})
    }
    txtTelefone_change =(event)=>{
        this.setState({telefone: event.target.value})
    }
    cboBairro_change =(event)=>{
        this.setState({bairro: event.target.value})
    }
    txtURL_change =(event)=>{
        this.setState({url: event.target.value})
    }
    preencherLista = () =>{
        const url = window.servidor + '/fornecedor/' 
            fetch(url)
            .then(response => response.json())
            .then(data =>{
                this.setState({fornecedores: data})
                
            })
    }
    carregar_bairros = () => {
        const url = window.servidor + '/bairro/'
        
        fetch(url)
            .then(response => response.json())
            .then(datab =>{
                this.setState({bairros: datab})
                
            })
            
    }
    iniciarNovo = () =>{
        this.setState({incluindo: true, id: '',  cep: '', endereco: '', facebook: '', foto: '', instagram: '', nome: '', telefone: '', tipo: '', url: '', whatsapp: '', bairro: '', usuario: ''})
    }
    componentDidMount(){
        this.carregar_bairros()
        if(this.props.fornecedor)
            this.iniciarAlterar(this.props.fornecedor)
    }
    iniciarAlterar =(fornecedor) =>{
        this.setState({alterando: true, id: fornecedor.id, cep: fornecedor.cep, endereco: fornecedor.endereco, facebook: fornecedor.facebool, foto: fornecedor.foto, instagram: fornecedor.instagram, nome: fornecedor.nome, telefone: fornecedor.telefone, tipo: fornecedor.tipo, url: fornecedor.url, whatsapp: fornecedor.whatsapp, bairro: fornecedor.bairro, usuario: fornecedor.usuario})
        
    }
    gravarAlterar =() =>{
        const dados ={
            "cep": this.state.cep,
            "endereco": this.state.endereco,
            "facebook": this.state.facebook,
            "foto":this.state.foto,
            "instagram": this.state.instagram,
            "nome": this.state.nome,
            "telefone": this.state.telefone,
            "tipo":this.state.tipo,
            "url": this.state.url,
            "whatsapp": this.state.whatsapp,
            "bairro": this.state.bairro,
            "usuario": this.state.usuario
        }
        const requestOptions = { 
            method: 'POST',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        };
        const url = window.servidor +  '/fornecedor/alterar'
        fetch(url, requestOptions) //"chamar o WebService"
            .then(this.setState({alterando: false}))
            .then(this.preencherLista())
            .catch(erro => console.log(erro));
    }
    excluir =(fornecedor) =>{
        const requestOptions = { 
            method: 'POST',
            headers:{
                'Content-Type': 'application/json'
            }
        };
        const url = window.servidor + '/fornecedor/excluir/' + fornecedor.id
        fetch(url, requestOptions)
            .then(this.preencherLista())
            .catch(erro => console.log(erro));
    }
    voltar =() =>{
        this.setState({voltar: true})
    }
    gravarNovo =() =>{
        const dados ={ //constante que não será mudada ao decorrer do processo
            "cep": this.state.cep,
            "endereco": this.state.endereco,
            "facebook": this.state.facebook,
            "foto":this.state.foto,
            "instagram": this.state.instagram,
            "nome": this.state.nome,
            "telefone": this.state.telefone,
            "tipo":this.state.tipo,
            "url": this.state.url,
            "whatsapp": this.state.whatsapp,
            "bairro": this.state.bairro,
            "usuario": this.props.novoUsuario
        }
        const requestOptions = { //constante para setar os valores
            method: 'POST',
            headers:{
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        };
        const url = window.servidor + '/fornecedor/'
        fetch(url, requestOptions) //"chamar o WebService"
            .then(()=>{
                this.setState({gravado: true})
                this.preencherLista()
            })
            .catch(erro => console.log(erro))
    }
    renderAlterar() {
        return (
            <div className="mb-2">
                <div className="row mt-2 pt-2" >
                    <div className="col-2">
                        ID:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.id} readOnly className="form-control name-pull-image" type="number"></input>   
                        </div>
                    </div>
                </div>
                <div className="row mt-2 pt-2" >
                    <div className="col-2">
                        Usuário:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.usuario.email} readOnly className="form-control name-pull-image" type="text"></input>   
                        </div>
                    </div>
                </div>
                <div className="row mt-2 pt-2" >
                    <div className="col-2">
                        Nome:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.nome} onChange={this.txtNome_change} className="form-control name-pull-image" type="text"></input>   
                        </div>
                    </div>
                </div>
                <div className="row mt-1 pt-2" >
                    <div className="col-2">
                        Endereço:
                    </div>
                    <div className="row mr-2 pt-2">
                        <div className="col-4">
                            <input value={this.state.endereco} onChange={this.txtEndereco_change} className="form-control name-pull-image" type="text"></input>  
                        </div>
                    </div>
                </div>
				<div className="row mr-2 pt-2" >
                    <div className="col-2">
                        CEP:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.cep} onChange={this.txtCep_change} className="form-control name-pull-image" type="text"></input>   
                        </div>
                    </div>
                </div>
			    <div className="row mr-2 pt-2" >
                    <div className="col-2">
                        Facebook:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.facebook} onChange={this.txtFacebook_change} className="form-control name-pull-image" type="text"></input>   
                        </div>
                    </div>
                </div>
				<div className="row mr-2 pt-2" >
                    <div className="col-2">
                        Foto:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.foto} className="form-control name-pull-image" type="text"></input>   
                        </div>
                    </div>
                </div>
                <div className="row mr-2 pt-2" >
                    <div className="col-2">
                        Instagram:
                    </div>
                    <div className="row mr-2 pt-2">
                        <div className="col-4">
                            <input value={this.state.instagram} onChange={this.txtInstagram_change} className="form-control name-pull-image" type="text"></input>  
                        </div>
                    </div>
                </div>
				<div className="row mr-2 pt-2" >
                    <div className="col-2">
                        Telefone:
                    </div>
                    <div className="row mr-2 pt-2" >
                        <div className="col-4">
                            <input value={this.state.telefone} onChange={this.txtTelefone_change} className="form-control name-pull-image" type="text"></input>   
                        </div>
                    </div>
                </div>
                <div className="row mr-2 pt-2" >
                    <div className="col-2">
                        WhatsApp:
                    </div>
                    <div className="row mr-2 pt-2">
                        <div className="col-4">
                            <input value={this.state.whatsapp} onChange={this.txtWhatsapp_change} className="form-control name-pull-image" type="text"></input>  
                        </div>
                    </div>
                </div>
                <div className="col-4 mt-1 ">
                    <label className="form-label">Bairro:</label>
                    <select value={this.state.bairro} className="form-select"  onChange={this.cboBairro_change}>
                        {this.state.bairros.map((bairro) => (
                            <option key={bairro.id} value={bairro.id}>{bairro.nome}</option>
                        ))}
                    </select>
                </div>
                <div className="row mt-2">
                    <div className="col-1">
                        <button className="btn btn-primary"  onClick = {() => this.gravarAlterar()}>Gravar</button>
                    </div>
                    <div className="col-1 ml-3">
                        <button className="btn btn-primary" onClick ={() => this.voltar()} >Voltar</button>
                    </div>
                </div>
            </div>
        )
    }
    renderCadastrarNovo = () => {
        return (
            <div>
                <div className="mt-5 pt-5 col-4">
                <h4>CADASTRO FORNECEDOR</h4>
                </div>
                <div className="row pt-1 col-4" >
                    Usuario:
                    <input value={this.props.novoUsuario.email} readOnly className="form-control name-pull-image"></input>
                </div>
                <div className="row pt-1">
                    Nome:
                </div>
                <div className="row pt-1" >
                    <div className="col-4">
                        <input value={this.state.nome} onChange={this.txtNome_change} className="form-control name-pull-image" type="text"></input>
                    </div>
                </div>
                <div className="col-2">
                    Endereço:
                </div>
                <div className="row pt-2">
                    <div className="col-4">
                        <input value={this.state.endereco} onChange={this.txtEndereco_change} className="form-control name-pull-image" type="text"></input>
                    </div>
                </div>
                <div className="col-2">
                    CEP:
                </div>
                <div className="row pt-2" >
                    <div className="col-4">
                        <input value={this.state.cep} onChange={this.txtCep_change} className="form-control name-pull-image" type="text"></input>
                    </div>
                </div>
                <div className="row pt-2" >
                    <div className="col-2">
                        Facebook:
                    </div>
                </div>
                <div className="row pt-2" >
                    <div className="col-4">
                        <input value={this.state.facebook} onChange={this.txtFacebook_change} className="form-control name-pull-image" type="text"></input>
                    </div>
                </div>
                <div className="row pt-2" >
                    <div className="col-2">
                        Instagram:
                    </div>
                </div>
                <div className="row pt-2" >
                    <div className="col-4">
                        <input value={this.state.instagram} onChange={this.txtInstagram_change} className="form-control name-pull-image" type="text"></input>
                    </div>
                </div>
                <div className="row pt-2" >
                    <div className="col-2">
                        Telefone:
                    </div>
                </div>
                <div className="col-4">
                    <input value={this.state.telefone} onChange={this.txtTelefone_change} className="form-control name-pull-image" type="text"></input>
                </div>
                <div className="row mr-2 pt-2" >
                    <div className="col-2">
                        WhatsApp:
                    </div>
                </div>
                <div className="col-4">
                    <input value={this.state.whatsapp} onChange={this.txtWhatsapp_change} className="form-control name-pull-image" type="text"></input>
                </div>
                <div className="col-4 mt-1 ">
                    <label className="form-label">Bairro:</label>
                    <select value={this.state.bairro} className="form-select" onChange={this.cboBairro_change}>
                        {this.state.bairros.map((bairro) => (
                            <option key={bairro.id} value={bairro.id}>{bairro.nome}</option>
                        ))}
                    </select>
                </div>
                <div className="row mr-2 pt-2" >
                    <div className="col-2">
                        URL:
                    </div>
                </div>
                <div className="col-4">
                    <input value={this.state.url} onChange={this.txtURL_change} className="form-control name-pull-image" type="text"></input>
                </div>
                <div className="row pt-2">
                    <figure className="figure">
                        <img src={this.state.foto} alt="Foto Fornecedor" width="15%" className="img-thumbnail rounded" />
                    </figure>
                    <input type="file" onChange={this.foto_change}/>
                </div>
                <div className="row mt-2 mb-5">
                    <div className="col-1">
                        <button className="btn btn-primary" onClick={() => this.gravarNovo()}>Gravar</button>
                    </div>
                    <div className="col-1">
                        <button className="btn btn-primary" onClick={() => this.voltar()} >Voltar</button>
                    </div>
                </div>
            </div>
        )
    }
    renderExibirLista = () =>{
        return(
            <div className="mt-5 pt-4">
                <button type="button" class="btn btn-danger mt-2" onClick ={() =>this.iniciarNovo()}>Novo</button>
                <table id="tabela" className ="table">
                    <thead>
                        <tr>
                            <th scope ="col">ID</th>
                            <th scope ="col">CEP</th>
                            <th scope ="col">Endereço</th>
                            <th scope ="col">Facebook</th>
                            <th scope ="col">Foto</th>
                            <th scope ="col">Instagram</th>
                            <th scope ="col">Nome</th>
                            <th scope ="col">Telefone</th>
                            <th scope ="col">Tipo de Usuário</th>
                            <th scope ="col">URL</th>
                            <th scope ="col">WhatsApp</th>
                            <th scope ="col">Bairro</th>
                            <th scope ="col">Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.fornecedores && this.state.fornecedores.map(fornecedor =>{
                            return <tr key={fornecedor.id}>
                                <th scope ="row">{fornecedor.id}</th>
                                <td>{fornecedor.cep}</td>
                                <td>{fornecedor.endereco}</td>
                                <td>{fornecedor.facebook}</td>
                                <td><img src={fornecedor.foto} alt="Foto Fornecedor" width="120%" className="img-thumbnail img-fluid rounded mx-auto d-block"></img></td>
                                <td>{fornecedor.instagram}</td>
                                <td>{fornecedor.nome}</td>
                                <td>{fornecedor.telefone}</td>
                                <td>{fornecedor.tipo}</td>
                                <td>{fornecedor.url}</td>
                                <td>{fornecedor.whatsapp}</td>
                                <td>{fornecedor.bairro}</td>
                                <td>{fornecedor.usuario}</td>
                                <><button onClick ={() => this.iniciarAlterar(fornecedor)} type="button" className="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Editar Fornecedor"><i className="bi bi-pencil-square"></i></button></>
                                <td><button onClick ={() => this.excluir(fornecedor)} type="button" className="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Excluir Fornecedor"><i className="bi bi-trash"></i></button></td>
                            </tr>
                        })}
                    </tbody>
                </table>
            </div>
        )
    }
    
    render() {
        let pagina=''
        if((this.props.novoUsuario)&&(!this.state.voltar)){
            pagina = this.renderCadastrarNovo()
        }else
            if(this.state.gravado){
                pagina = <Anuncio/>
            }else
                if(this.state.voltar){
                    pagina = <Login/>
                }else
                    if((this.state.alterando)&&(!this.props.novoUsuario)){
                        pagina = this.renderAlterar()
                    }else
                        pagina = this.renderExibirLista()
        return pagina        
    }
}
