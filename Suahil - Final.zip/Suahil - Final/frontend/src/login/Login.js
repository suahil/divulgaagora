import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Usuario from '../usuario/Usuario'
import Fornecedor from '../fornecedor/Fornecedor'

export default class Login extends Component {

    state = {
        usuario: "",
        logado: false,
        email: "",
        senha: "",
        fornecedor: ""
        
    }

    constructor(props) {
        super(props)
        
        this.state = {
            usuario: this.props.usuario, 
            logado:this.props.logado,
            fornecedor:this.props.fornecedor
        }
    }
        
    txtEmail_change = (event) => {
        this.setState({email: event.target.value})
    }
    txtSenha_change = (event) => {
        this.setState({senha: event.target.value})
    }

    login = (email,senha) => {
        this.props.autenticar(email,senha)
        
    }

    cadastro = () => {
        return <Usuario />
    }

    renderLogado(){
        return (
            <div className='mt-5 p-4'>
                <h5>Bem vindo</h5> {this.props.usuario.email}
                <h5>Você é um </h5> {this.props.usuario.tipoUsuario}
            </div>
        )
    }

    renderDeslogado(){
        return (
            <div className="col-5 container mt-5 p-4 ">
                
                <div className="mb-3">
                    <label for="exampleDropdownFormEmail2" className="form-label">Email</label>
                    <input type="email" onChange={this.txtEmail_change} className="form-control" id="exampleDropdownFormEmail2" placeholder="Digite seu e-mail"></input>
                </div>
                <div className="mb-3">
                    <label for="exampleDropdownFormPassword2" className="form-label">Senha</label>
                    <input type="password" onChange={this.txtSenha_change} className="form-control" id="exampleDropdownFormPassword2" placeholder="Senha"></input>
                </div>
                <div className="mb-3">
                    <div className="form-check">
                        <input type="checkbox" className="form-check-input" id="dropdownCheck2"></input>
                        <label className="form-check-label" for="dropdownCheck2">Lembrar de mim</label>
                    </div>
                </div>
                <button type="submit" className="btn btn-primary" onClick = {() => this.login(this.state.email,this.state.senha)}>Entrar</button>
                <div className="mb-3">
                    <br/>
                    <h5>Não tem cadastro ainda?
                        <Link className="navbar-brand" to="/usuario"> Cadastre-se!</Link>
                        
                    </h5>                                        
                </div>

            </div>
        )

    }
    
    render() {
        let pagina = ''
        
        if((this.props.logado)&&(this.props.fornecedor))
            pagina = <Fornecedor/>
        else if((this.props.logado)&&(!this.props.fornecedor))
            pagina = this.renderLogado()    
        else
            pagina = this.renderDeslogado()    
        
        return pagina        
    }
}
