import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Anuncio from '../anuncio/Anuncio'
import Login from '../login/Login'

export default class Menu extends Component {
    state = {
        usuario: "",
        logado: false,
        busca:""
        
    }

    constructor(props) {
        super(props)
        
        this.state = {
            usuario: this.props.usuario, 
            logado:this.props.logado
        }
        
    }

    txtBusca_change = (event) => {
        this.setState({busca: event.target.value})
    } 

    buscarAnuncio = (busca) => {
        this.props.buscarAnuncio(busca)
    }

    sair = () => {
        this.props.deslogar()
        return <Login/>
    }

    meusAnuncios = () => {
        return <Anuncio/>
    }

    meusDados = () => {
        this.props.carregarFornecedor()
    
    }

    renderMenuDeslogado = () => {
        return (
            <nav className="navbar navbar-expand-lg navbar-dark bg-light fixed-top">
                <div className="container-fluid col-12 bg-dark text-white p-2">
                    <Link className="navbar-brand" to="/"><i class="bi bi-house"></i></Link>
                    <div className="col-4 d-flex">
                        <input id="txt_consulta" className="form-control" onChange={this.txtBusca_change} type="search" placeholder="Pesquisar" aria-label="Pesquisar"></input>
                        <button className="w-25 btn btn-dark" onClick={() => this.buscarAnuncio(this.state.busca)} type="button"><i class="bi bi-search"></i></button>
                    </div>
                    <div className="float-right">
                        <Link className="navbar-brand" to="/login">Login</Link>
                    </div>
                </div>
            </nav>
            )
    }

    renderMenuLogado = () => {
        return (
            <nav className="navbar navbar-expand-lg navbar-dark bg-light">
                <div className="container-fluid col-12 bg-dark text-white p-2">
                    <Link className="navbar-brand" to="/"><i class="bi bi-house"></i></Link>
                    <div className="col-4 d-flex">
                        <input id="txt_consulta" className="form-control" onChange={this.txtBusca_change} type="search" placeholder="Pesquisar" aria-label="Pesquisar"></input>
                        <button className="w-25 btn btn-dark" onClick={() => this.buscarAnuncio(this.state.busca)} type="button"><i class="bi bi-search"></i></button>
                    </div>
                    <div className="col-3 d-flex">
                        <button className="btn btn-link" onClick={() => this.meusDados()} type="button">{this.props.usuario.email}</button>
                        <Link className="navbar-brand" to="/anuncio" ><h6>Meus Anuncios</h6></Link>
                        <button className="btn btn-secondary btn-sm" type="button" onClick={() => this.sair()}>Sair</button>
                    </div>
                </div>
            </nav>
            )
    }

    renderMenuLogadoAdm = () => {
        return (
            <nav className="navbar navbar-expand-lg navbar-dark bg-light">
                <div className="container-fluid col-12 bg-dark text-white p-2">
                    <Link className="navbar-brand" to="/"><i class="bi bi-house"></i></Link>
                    <div className="col-4 d-flex">
                        <input id="txt_consulta" className="form-control" onChange={this.txtBusca_change} type="search" placeholder="Pesquisar" aria-label="Pesquisar"></input>
                        <button className="w-25 btn btn-dark" onClick={() => this.buscarAnuncio(this.state.busca)} type="button"><i class="bi bi-search"></i></button>
                    </div>
                    <div className="col-4 d-flex">
                        <Link className="navbar-brand" to="/anuncio" >{this.props.usuario.email}</Link>
                        <Link className="navbar-brand" to="/usuario">Usuarios</Link>
                        <button className="btn btn-secondary btn-sm" type="button" onClick={() => this.sair()}>Sair</button>
                    </div>
                </div>
            </nav>
            )
    }

        
    render() {
        let pagina = ''
        
        if(!this.props.logado){
            pagina = this.renderMenuDeslogado()
            
        } else {
            if(this.props.usuario.tipoUsuario==='ADMINISTRADOR'){
                pagina = this.renderMenuLogadoAdm()
            } else
                pagina = this.renderMenuLogado()
        }
        return pagina
    }
}
