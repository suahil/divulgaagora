package org.ds2.divulgaagora.controller;

import java.util.ArrayList;
import java.util.List;
import org.ds2.divulgaagora.controller.request.AnuncioRs;
import org.ds2.divulgaagora.model.Anuncio;
import org.ds2.divulgaagora.model.Categoria;
import org.ds2.divulgaagora.model.Fornecedor;
import org.ds2.divulgaagora.model.FotoAnuncio;
import org.ds2.divulgaagora.model.TipoProduto;
import org.ds2.divulgaagora.model.Usuario;
import org.ds2.divulgaagora.repository.AnuncioRepository;
import org.ds2.divulgaagora.repository.CategoriaRepository;
import org.ds2.divulgaagora.repository.FornecedorRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/anuncio")
public class AnuncioController {
    private final AnuncioRepository anuncioRepository;
    private final FornecedorRepository fornecedorRepository;
    private final CategoriaRepository categoriaRepository;
        
    public AnuncioController(AnuncioRepository anuncioRepository, FornecedorRepository fornecedorRepository,
    CategoriaRepository categoriaRepository) {
        this.anuncioRepository = anuncioRepository;
        this.fornecedorRepository = fornecedorRepository;
        this.categoriaRepository = categoriaRepository;
    }
    
    @CrossOrigin
    @GetMapping("/tipos")
    public TipoProduto[] getTipos(){
        return TipoProduto.values();
    }

    @CrossOrigin
    @GetMapping("/aprovados")
    public List<AnuncioRs> getAnunciosAprovados(){
        List<Anuncio> anuncios = anuncioRepository.getAprovados();
        List<AnuncioRs> anrs = new ArrayList<AnuncioRs>();

        for (Anuncio anuncio:anuncios){
            AnuncioRs an = new AnuncioRs();
            an.setCategoria(anuncio.getCategoria().getNome());
            an.setDescricao(anuncio.getDescricao());
            an.setFornecedor(anuncio.getFornecedor().getNome());
            an.setId(anuncio.getId());
            an.setNome(anuncio.getNome());
            an.setTipoproduto(anuncio.getTipoproduto().toString());
            an.setValor(anuncio.getValor());
            an.setFotoFornecedor(anuncio.getFornecedor().getFoto());
            an.setAprovacao(anuncio.getAprovacao().getEmail());
            anrs.add(an);
        }
        return anrs;
    }
    
    @CrossOrigin
    @GetMapping("/reprovados")
    public List<AnuncioRs> getAnunciosReprovados(){
        List<Anuncio> anuncios = anuncioRepository.getReprovados();
        List<AnuncioRs> anrs = new ArrayList<AnuncioRs>();

        for (Anuncio anuncio:anuncios){
            AnuncioRs an = new AnuncioRs();
            an.setCategoria(anuncio.getCategoria().getNome());
            an.setDescricao(anuncio.getDescricao());
            an.setFornecedor(anuncio.getFornecedor().getNome());
            an.setId(anuncio.getId());
            an.setNome(anuncio.getNome());
            an.setTipoproduto(anuncio.getTipoproduto().toString());
            an.setValor(anuncio.getValor());
            an.setFotoFornecedor(anuncio.getFornecedor().getFoto());
            anrs.add(an);
        }
        return anrs;
    }
    
    @CrossOrigin
    @GetMapping("/aprovados/{busca}")
    public List<AnuncioRs> getAnunciosBuscaAprovados(@PathVariable("busca") String busca){
        List<Anuncio> anuncios = anuncioRepository.getBuscaAprovados(busca.toUpperCase());
        List<AnuncioRs> anrs = new ArrayList<AnuncioRs>();

        for (Anuncio anuncio:anuncios){
            AnuncioRs an = new AnuncioRs();
            an.setCategoria(anuncio.getCategoria().getNome());
            an.setDescricao(anuncio.getDescricao());
            an.setFornecedor(anuncio.getFornecedor().getNome());
            an.setId(anuncio.getId());
            an.setNome(anuncio.getNome());
            an.setTipoproduto(anuncio.getTipoproduto().toString());
            an.setValor(anuncio.getValor());
            an.setFotoFornecedor(anuncio.getFornecedor().getFoto());
            an.setAprovacao(anuncio.getAprovacao().getEmail());
            anrs.add(an);
        }
        return anrs;
    }
    
    @CrossOrigin
    @GetMapping("/fornecedor/{email}")
    public List<AnuncioRs> getAnunciosPorFornecedor(@PathVariable("email") String email){
        List<Anuncio> anuncios = anuncioRepository.getAnunciosPorFornecedor(email);
        List<AnuncioRs> anrs = new ArrayList<AnuncioRs>();

        for (Anuncio anuncio:anuncios){
            AnuncioRs an = new AnuncioRs();
            an.setCategoria(anuncio.getCategoria().getNome());
            an.setDescricao(anuncio.getDescricao());
            an.setFornecedor(anuncio.getFornecedor().getNome());
            an.setId(anuncio.getId());
            an.setNome(anuncio.getNome());
            an.setTipoproduto(anuncio.getTipoproduto().toString());
            an.setValor(anuncio.getValor());
            an.setFotoFornecedor(anuncio.getFornecedor().getFoto());
            if(anuncio.getAprovacao()!=null){
                an.setAprovacao(anuncio.getAprovacao().getEmail());    
            }
            anrs.add(an);
        }
        return anrs;
    }
    
    @CrossOrigin
    @GetMapping("/")
    public List<AnuncioRs> getAnuncios(){
        List<Anuncio> anuncios = anuncioRepository.findAll();
        List<AnuncioRs> anrs = new ArrayList<AnuncioRs>();
        
        
        for (Anuncio anuncio:anuncios){
            AnuncioRs an = new AnuncioRs();
            an.setCategoria(anuncio.getCategoria().getNome());
            an.setDescricao(anuncio.getDescricao());
            an.setFornecedor(anuncio.getFornecedor().getNome());
            an.setId(anuncio.getId());
            an.setNome(anuncio.getNome());
            an.setTipoproduto(anuncio.getTipoproduto().toString());
            an.setValor(anuncio.getValor());
            an.setFotoFornecedor(anuncio.getFornecedor().getFoto());
                        
            List<FotoAnuncio> fotos = anuncio.getFotos();
            for (FotoAnuncio ft:fotos){
                an.salvarFoto(ft.getFoto());
            }
            
            anrs.add(an);
        }
        return anrs;
    }
    
    @CrossOrigin
    @GetMapping("/{id}")
    public AnuncioRs getAnuncio(@PathVariable("id") Long id){
        Anuncio anuncio = anuncioRepository.getById(id);
        AnuncioRs anrs = new AnuncioRs();

        anrs.setCategoria(anuncio.getCategoria().getNome());
        anrs.setDescricao(anuncio.getDescricao());
        anrs.setFornecedor(anuncio.getFornecedor().getNome());
        anrs.setId(anuncio.getId());
        anrs.setNome(anuncio.getNome());
        anrs.setTipoproduto(anuncio.getTipoproduto().toString());
        anrs.setValor(anuncio.getValor());
        anrs.setFotoFornecedor(anuncio.getFornecedor().getFoto());
        anrs.setAprovacao(anuncio.getAprovacao().getEmail());

        List<FotoAnuncio> fotosan = anuncio.getFotos();
        for (FotoAnuncio ft : fotosan) {
            System.out.println(ft.getFoto());
            anrs.salvarFoto(ft.getFoto());
            
        }


        return anrs;
    }
    @CrossOrigin
    @GetMapping("/visualizar/{id}")
    public Anuncio getAnuncio1(@PathVariable("id") Long id){
        Anuncio anuncio = anuncioRepository.getById(id);
        return anuncio;
    }
    
    @CrossOrigin
    @PostMapping("/aprovar/{id]/{usuario}")
    public void aprovarAnuncio(@RequestBody Long id, Usuario usuario){
        Anuncio an = anuncioRepository.getById(id);
        an.setAprovacao(usuario);
        anuncioRepository.save(an);
    }

    @CrossOrigin
    @PostMapping("/incluir")
    public void gravar(@RequestBody AnuncioRs anuncioRs) throws Exception{
        Anuncio anuncio = new Anuncio();
        
        anuncio.setNome(anuncioRs.getNome());
        anuncio.setDescricao(anuncioRs.getDescricao());   
        anuncio.setValor(anuncioRs.getValor());
        if(anuncioRs.getTipoproduto().toUpperCase().equals("NOVO")) {
            anuncio.setTipoproduto(TipoProduto.NOVO);
        } else if(anuncioRs.getTipoproduto().toUpperCase().equals("USADO")) {
            anuncio.setTipoproduto(TipoProduto.USADO);
        } else {
            throw new Exception("Tipo de produto inválido.");
        }
        List<Categoria> categorias = categoriaRepository.findAll();
        Categoria categoria = null;
        for (Categoria c: categorias){
            if(c.getNome().equals(anuncioRs.getCategoria())){
                categoria = c;
            }
        }
        if (categoria==null){
            categoria = new Categoria();
            categoria.setNome(anuncioRs.getCategoria());
            categoriaRepository.save(categoria);
        }
        anuncio.setCategoria(categoria);
        
        List<Fornecedor> fornecedores = fornecedorRepository.findAll();
        Fornecedor fornecedor = null;
        for (Fornecedor f: fornecedores){
            if(f.getNome().equals(anuncioRs.getFornecedor())) {
                fornecedor = f;
            }
        }
        if (fornecedor==null){
            throw new Exception("Fornecedor não encontrado");
        }
        anuncio.setFornecedor(fornecedor);
        
        List<String> fotos = anuncioRs.getFotos();
            for (String foto:fotos){
                FotoAnuncio fotoAnuncio = new FotoAnuncio();
                fotoAnuncio.setFoto(foto);
                anuncio.salvarFoto(fotoAnuncio);
            }
        
        anuncioRepository.save(anuncio);

    }

    @CrossOrigin
    @GetMapping("/excluir/{id}")
    public void remover(@PathVariable("id") Long id) throws Exception{
        var a = anuncioRepository.findById(id);

        if(a.isPresent()){
            Anuncio anuncio = a.get();
            anuncioRepository.delete(anuncio);
        } else {
            throw new Exception("Id não encontrado!");
        }
    }
  
}
