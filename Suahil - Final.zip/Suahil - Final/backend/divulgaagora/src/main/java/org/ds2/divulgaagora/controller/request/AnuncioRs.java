package org.ds2.divulgaagora.controller.request;

import java.util.List;


public class AnuncioRs {
    private Long id;
    private String nome;
    private String fornecedor;
    private String descricao;
    private Double valor;
    private String categoria;
    private String fotoFornecedor;
    private String tipoproduto;
    private String aprovacao;
    private List<String> fotos;
    
    public List<String> getFotos() {
        return fotos;
    }
    public void setFotos(List<String> fotos) {
        this.fotos = fotos;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getFornecedor() {
        return fornecedor;
    }
    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public Double getValor() {
        return valor;
    }
    public void setValor(Double valor) {
        this.valor = valor;
    }
    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    public String getTipoproduto() {
        return tipoproduto;
    }
    public void setTipoproduto(String tipoproduto) {
        this.tipoproduto = tipoproduto;
    }
    public String getFotoFornecedor() {
        return fotoFornecedor;
    }
    public void setFotoFornecedor(String fotoFornecedor) {
        this.fotoFornecedor = fotoFornecedor;
    }
    public String getAprovacao() {
        return aprovacao;
    }
    public void setAprovacao(String aprovacao) {
        this.aprovacao = aprovacao;
    }
    public void salvarFoto(String foto) {
        fotos.add(foto);
    }

    


}
