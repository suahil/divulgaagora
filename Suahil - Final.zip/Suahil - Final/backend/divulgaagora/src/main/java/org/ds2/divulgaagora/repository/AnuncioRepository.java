package org.ds2.divulgaagora.repository;

import java.util.List;

import org.ds2.divulgaagora.model.Anuncio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AnuncioRepository extends JpaRepository<Anuncio, Long> {
    
    @Query("SELECT a FROM Anuncio a WHERE a.aprovacao is not null")
    public List<Anuncio> getAprovados();
    
    @Query("SELECT a FROM Anuncio a WHERE a.fornecedor.usuario.email = :email")
    public List<Anuncio> getAnunciosPorFornecedor(String email);
    
    @Query("SELECT a FROM Anuncio a WHERE a.aprovacao is not null AND UPPER(a.nome) LIKE %:busca% OR a.aprovacao is not null AND UPPER(a.descricao) LIKE %:busca%")
    public List<Anuncio> getBuscaAprovados(String busca);
    
    @Query("SELECT a FROM Anuncio a WHERE a.aprovacao IS NULL")
    public List<Anuncio> getReprovados();
    
    @Query("SELECT a FROM Anuncio a WHERE a.id = :id")
    public Anuncio getById(Long id);

}
