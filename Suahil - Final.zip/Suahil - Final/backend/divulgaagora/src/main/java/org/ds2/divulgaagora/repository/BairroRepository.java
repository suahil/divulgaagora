package org.ds2.divulgaagora.repository;

import org.ds2.divulgaagora.model.Bairro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BairroRepository extends JpaRepository<Bairro, Long> {
    
}
