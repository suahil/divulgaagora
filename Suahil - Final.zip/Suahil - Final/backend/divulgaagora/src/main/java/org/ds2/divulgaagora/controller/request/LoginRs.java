package org.ds2.divulgaagora.controller.request;

public class LoginRs {
    private Long id;
    private String email;
    private String senha;
    private String tipoUsuario;
    
    public Long getId() {
        return id;
    }
    

    public LoginRs(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }


    public void setId(Long id) {
        this.id = id;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }


    public String getTipoUsuario() {
        return tipoUsuario;
    }


    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    
}
