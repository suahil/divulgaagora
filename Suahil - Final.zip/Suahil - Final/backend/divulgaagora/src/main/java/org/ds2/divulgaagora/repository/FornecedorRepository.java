package org.ds2.divulgaagora.repository;

import org.ds2.divulgaagora.model.Fornecedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FornecedorRepository extends JpaRepository<Fornecedor, Long> {

    @Query("SELECT f FROM Fornecedor f where :id=f.usuario.id")
    Fornecedor findByUsuario(Long id);
    
}
