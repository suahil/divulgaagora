package org.ds2.divulgaagora.controller;

import java.util.ArrayList;
import java.util.List;

import org.ds2.divulgaagora.controller.request.FornecedorRs;
import org.ds2.divulgaagora.model.Fornecedor;
import org.ds2.divulgaagora.repository.FornecedorRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fornecedor")
public class FornecedorController {
    private final FornecedorRepository fornecedorRepository;

    public FornecedorController(FornecedorRepository fornecedorRepository) {
        this.fornecedorRepository = fornecedorRepository;
    }
    
    @CrossOrigin
    @PostMapping("/")
    public void gravar(@RequestBody Fornecedor fornecedor){
        fornecedorRepository.save(fornecedor);

    }
    @CrossOrigin
    @GetMapping("/{id}")
    public void remover(@PathVariable("id") Long id) throws Exception{
        var f = fornecedorRepository.findById(id);

        if(f.isPresent()){
            Fornecedor fornecedor = f.get();
            fornecedorRepository.delete(fornecedor);
        } else {
            throw new Exception("Id não encontrado!");
        }
    }
    
    @CrossOrigin
    @GetMapping("/buscarFornecedor/{id}")
    public FornecedorRs buscarFornecedor(@PathVariable("id") Long id) {
        Fornecedor fornecedor = fornecedorRepository.findByUsuario(id);
        FornecedorRs fRs = new FornecedorRs();
        fRs.setEndereco(fornecedor.getEndereco());
        fRs.setNome(fornecedor.getNome());    
        fRs.setTelefone(fornecedor.getTelefone());
        fRs.setCep(fornecedor.getCep());
        fRs.setFacebook(fornecedor.getFacebook());
        fRs.setFoto(fornecedor.getFoto());
        fRs.setInstagram(fornecedor.getInstagram());
        fRs.setWhatsapp(fornecedor.getWhatsapp());
        fRs.setId(fornecedor.getId());
        fRs.setBairro(fornecedor.getBairro().getNome());
        
        return fRs;

    }

    @CrossOrigin
    @GetMapping("/")
    public List<FornecedorRs> getFornecedores() {
        List<Fornecedor> fornecedors = fornecedorRepository.findAll();

        List<FornecedorRs> frs = new ArrayList<FornecedorRs>();

        for(Fornecedor fornecedor: fornecedors){
            FornecedorRs fl = new FornecedorRs();
            fl.setId(fornecedor.getId());
            fl.setNome(fornecedor.getNome());
            fl.setEndereco(fornecedor.getEndereco());
            fl.setTelefone(fornecedor.getTelefone());
            fl.setCep(fornecedor.getCep());
            fl.setFacebook(fornecedor.getFacebook());
            fl.setFoto(fornecedor.getFoto());
            fl.setInstagram(fornecedor.getInstagram());
            fl.setWhatsapp(fornecedor.getWhatsapp());
            fl.setUsuario(fornecedor.getUsuario().getEmail());
            
            frs.add(fl);
        }
        return frs;
    }

    @CrossOrigin
    @PostMapping("/alterar")
    public void alterar(@RequestBody FornecedorRs fRs) throws Exception{
        var objeto = fornecedorRepository.findById(fRs.getId());
        if (objeto.isPresent()) {
            Fornecedor fornecedor = objeto.get();
            fornecedor.setEndereco(fRs.getEndereco());
            fornecedor.setNome(fRs.getNome());
            fornecedor.setTelefone(fRs.getTelefone());
            fornecedor.setCep(fRs.getCep());
            fornecedor.setFacebook(fRs.getFacebook());
            fornecedor.setFoto(fRs.getFoto());
            fornecedor.setInstagram(fRs.getInstagram());
            fornecedor.setWhatsapp(fRs.getWhatsapp());
            if(!(fRs.getId() == null)){
                fornecedor.setId(fRs.getId());
                fRs.setBairro(fRs.getBairro());
            }
            fornecedorRepository.save(fornecedor);
        } else {
            throw new Exception("Não foi possível alterar o fornecedor");
        }
    }

}
