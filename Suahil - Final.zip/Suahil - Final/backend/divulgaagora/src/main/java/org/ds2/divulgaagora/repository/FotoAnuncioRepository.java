package org.ds2.divulgaagora.repository;

import org.ds2.divulgaagora.model.FotoAnuncio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FotoAnuncioRepository extends JpaRepository<FotoAnuncio, Long> {
    
}
