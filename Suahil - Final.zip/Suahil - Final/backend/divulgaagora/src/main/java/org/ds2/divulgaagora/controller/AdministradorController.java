package org.ds2.divulgaagora.controller;

import java.util.List;

import org.ds2.divulgaagora.model.Administrador;
import org.ds2.divulgaagora.repository.AdministradorRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/administrador")
public class AdministradorController {
    private final AdministradorRepository administradorRepository;

    public AdministradorController(AdministradorRepository administradorRepository) {
        this.administradorRepository = administradorRepository;
    }

    @GetMapping("/")
    public List<Administrador> getAdministradores(){
        return administradorRepository.findAll();
        
    }

    @PostMapping("/")
    public void gravar(@RequestBody Administrador administrador){
        administradorRepository.save(administrador);
    }
}
