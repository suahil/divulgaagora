package org.ds2.divulgaagora.controller;

import java.util.ArrayList;
import java.util.List;

import org.ds2.divulgaagora.controller.request.CategoriaRs;
import org.ds2.divulgaagora.model.Categoria;
import org.ds2.divulgaagora.repository.CategoriaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/categoria")
public class CategoriaController {
    private final CategoriaRepository categoriaRepository;

    public CategoriaController(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    @CrossOrigin
    @GetMapping("/")
    public List<CategoriaRs> getCategorias(){
        List<Categoria> categorias = categoriaRepository.findAll();
        List<CategoriaRs> catrs = new ArrayList<CategoriaRs>();

        for (Categoria categoria:categorias){
            CategoriaRs c = new CategoriaRs();
            c.setId(categoria.getId());
            c.setNome(categoria.getNome());
            catrs.add(c);
        }
        return catrs;
    }
    
    @PostMapping("/")
    public void gravar(@RequestBody Categoria categoria){
        categoriaRepository.save(categoria);

    }

    @GetMapping("/{id}")
    public void remover(@PathVariable("id") Long id) throws Exception{
        var c = categoriaRepository.findById(id);

        if(c.isPresent()){
            Categoria categoria = c.get();
            categoriaRepository.delete(categoria);
        } else {
            throw new Exception("Id não encontrado!");
        }
    }

}
