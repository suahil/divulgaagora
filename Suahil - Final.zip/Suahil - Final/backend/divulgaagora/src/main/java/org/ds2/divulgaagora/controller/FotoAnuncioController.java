package org.ds2.divulgaagora.controller;

import java.util.List;

import org.ds2.divulgaagora.model.FotoAnuncio;
import org.ds2.divulgaagora.repository.FotoAnuncioRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fotoanuncio")
public class FotoAnuncioController {
    private final FotoAnuncioRepository fotoAnuncioRepository;

    public FotoAnuncioController(FotoAnuncioRepository fotoAnuncioRepository) {
        this.fotoAnuncioRepository = fotoAnuncioRepository;
    }
    
    @GetMapping("/")
    public List<FotoAnuncio> getFotoAnuncios(){
        return fotoAnuncioRepository.findAll();
    }
    
    @PostMapping("/")
    public void gravar(@RequestBody FotoAnuncio fotoAnuncio){
        fotoAnuncioRepository.save(fotoAnuncio);

    }

    @GetMapping("/{id}")
    public void remover(@PathVariable("id") Long id) throws Exception{
        var f = fotoAnuncioRepository.findById(id);

        if(f.isPresent()){
            FotoAnuncio fotoAnuncio = f.get();
            fotoAnuncioRepository.delete(fotoAnuncio);
        } else {
            throw new Exception("Id não encontrado!");
        }
    }

}
