package org.ds2.divulgaagora.repository;

import java.util.List;

import org.ds2.divulgaagora.model.TipoUsuario;
import org.ds2.divulgaagora.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    public Usuario findByEmail(String email);
    public List<Usuario> findByTipousuario(TipoUsuario tipousuario);    

    @Query("SELECT u FROM Usuario u ORDER BY u.email")
    List<Usuario> findByOrdemAlfabetica();
}
