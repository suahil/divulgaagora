package org.ds2.divulgaagora.controller;

import java.util.ArrayList;
import java.util.List;

import org.ds2.divulgaagora.controller.request.LoginRs;
import org.ds2.divulgaagora.controller.request.UsuarioRetornoRs;
import org.ds2.divulgaagora.controller.request.UsuarioRs;
import org.ds2.divulgaagora.model.TipoUsuario;
import org.ds2.divulgaagora.model.Usuario;
import org.ds2.divulgaagora.repository.UsuarioRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    private final UsuarioRepository usuarioRepository;

    public UsuarioController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @CrossOrigin
    @GetMapping("/listar")
    public List<UsuarioRetornoRs> getUsuarios(){
        List<Usuario> usuarios = usuarioRepository.findAll();
        List<UsuarioRetornoRs> urs = new ArrayList<UsuarioRetornoRs>();

        for (Usuario usuario: usuarios){
            UsuarioRetornoRs u = new UsuarioRetornoRs();
            u.setEmail(usuario.getEmail());
            u.setId(usuario.getId());
            u.setTipoUsuario(usuario.getTipousuario().toString());
            urs.add(u);
        }
        return urs;
    }
    
    @CrossOrigin
    @GetMapping("/tipos")
    public TipoUsuario[] getTipos(){
        return TipoUsuario.values();
    }
    
    @CrossOrigin
    @GetMapping("/listaraz")
    public List<UsuarioRetornoRs> getUsuariosAZ(){
        List<Usuario> usuarios = usuarioRepository.findByOrdemAlfabetica();
        List<UsuarioRetornoRs> urs = new ArrayList<UsuarioRetornoRs>();

        for (Usuario usuario: usuarios){
            UsuarioRetornoRs u = new UsuarioRetornoRs();
            u.setEmail(usuario.getEmail());
            u.setId(usuario.getId());
            u.setTipoUsuario(usuario.getTipousuario().toString());
            urs.add(u);
        }
        return urs;
    }
    
    @CrossOrigin
    @PostMapping("/incluir")
    public Usuario gravar(@RequestBody UsuarioRs usuarioRs) {
        
        Usuario usuario = new Usuario();
        
            
            usuario.setEmail(usuarioRs.getEmail());
            usuario.setSenha(usuarioRs.getSenha());
            if(usuarioRs.getTipoUsuario().toUpperCase().equals("ADMINISTRADOR")) {
                usuario.setTipousuario(TipoUsuario.ADMINISTRADOR);
            } else if(usuarioRs.getTipoUsuario().toUpperCase().equals("FORNECEDOR")) {
                usuario.setTipousuario(TipoUsuario.FORNECEDOR);
            }
            usuarioRepository.save(usuario);
            return usuario;
        
    }
    
    @CrossOrigin
    @PostMapping("/alterar")
    public void alterar(@RequestBody UsuarioRs uRs) throws Exception{
        var objeto = usuarioRepository.findById(uRs.getId());
        if (objeto.isPresent()) {
            Usuario usuario = objeto.get();
            usuario.setEmail(uRs.getEmail());
            usuario.setSenha(uRs.getSenha());
            if(uRs.getTipoUsuario().toUpperCase().equals("ADMINISTRADOR")) {
                usuario.setTipousuario(TipoUsuario.ADMINISTRADOR);
            } else if(uRs.getTipoUsuario().toUpperCase().equals("FORNECEDOR")) {
                usuario.setTipousuario(TipoUsuario.FORNECEDOR);
            } else {
                throw new Exception("Tipo de usuário inválido.");
            }
            usuarioRepository.save(usuario);
        
		} else {
            throw new Exception("Não foi possível alterar o usuario");
        }
    }

    @CrossOrigin
    @GetMapping("/excluir/{id}")
    public void remover(@PathVariable("id") Long id) throws Exception{
        var u = usuarioRepository.findById(id);

        if(u.isPresent()){
            Usuario usuario = u.get();
            usuarioRepository.delete(usuario);
        } else {
            throw new Exception("Id não encontrado!");
        }
    }
    @CrossOrigin
    @GetMapping("/email/{email}")
    public UsuarioRetornoRs getUsuarioPorEmail(@PathVariable("email") String email){
        Usuario usuario = new Usuario();
        usuario = usuarioRepository.findByEmail(email);
        UsuarioRetornoRs urs = new UsuarioRetornoRs();
        urs.setId(usuario.getId());
        urs.setEmail(usuario.getEmail());
        urs.setTipoUsuario(usuario.getTipousuario().toString());

        return urs;
    }
    @CrossOrigin
    @GetMapping("/tipo/{tipo}")
    public List<UsuarioRetornoRs> getUsuariosPorTipo(@PathVariable("tipo") TipoUsuario tipousuario){
        List<Usuario> usuarios = usuarioRepository.findByTipousuario(tipousuario);
        List<UsuarioRetornoRs> urs = new ArrayList<UsuarioRetornoRs>();
        
        for(Usuario usuario : usuarios){
            UsuarioRetornoRs u = new UsuarioRetornoRs();
            u.setId(usuario.getId());
            u.setEmail(usuario.getEmail());
            u.setTipoUsuario(usuario.getTipousuario().toString());

            urs.add(u);
        }
        return urs;
    }

    @CrossOrigin
    @GetMapping("/logar/{email}/{senha}")
    public LoginRs Logar(@PathVariable("email") String email, @PathVariable("senha") String senha) throws Exception{
        LoginRs login = new LoginRs(email, senha);
        Usuario us = usuarioRepository.findByEmail(email);
        if(us != null){
            if(login.getSenha().equals(us.getSenha())){
                login.setId(us.getId());
                login.setTipoUsuario(us.getTipousuario().toString());
                login.setSenha(null);
                return login;
            } else {
                throw new Exception("Senha incorreta");
            }
        } else
            throw new Exception("Usuário não encontrado");
        
    }    
    
}
